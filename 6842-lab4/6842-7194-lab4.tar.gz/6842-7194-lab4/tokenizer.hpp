#include <bits/stdc++.h>

using namespace std;

bool sortColumn(const vector<string> &v1, const vector<string> &v2);

void typeTokenizer(vector<vector<int>> &);

void processesTokenizer(vector<vector<string>> &data, int n);

void displayData(vector<vector<int>> data);
